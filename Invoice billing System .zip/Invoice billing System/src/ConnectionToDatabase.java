import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionToDatabase {
    public static Connection connectToDb() {
        Connection conn = null;
        try {
            // Provide the database URL, username, and password
            String url = "jdbc:mysql://localhost:3306/inbill";
            String username = "root";
            String password = ""; 
            
            // Establish the connection
            conn = DriverManager.getConnection(url, username, password);
            System.out.println("Connected to the database successfully!");
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database: " + e.getMessage());
        }
        return conn;
    }
}
