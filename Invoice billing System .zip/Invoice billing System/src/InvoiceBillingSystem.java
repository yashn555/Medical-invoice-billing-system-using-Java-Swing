import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.*;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class InvoiceBillingSystem extends JFrame {
    private JTextField searchBar;
    private JList<String> productList;
    private DefaultListModel<String> productListModel;
    private JTable invoiceTable;
    private DefaultTableModel invoiceTableModel;
    private JLabel totalLabel;
    private JButton printButton;
    private JButton backButton;
    private JButton transactionHistoryButton; // Added button for Transaction History
    private Connection connection;

    public InvoiceBillingSystem() {
        searchBar = new JTextField(20);
        totalLabel = new JLabel("Total: $0.00");
        printButton = new JButton("Print Bill");
        backButton = new JButton("Add Stock");
        transactionHistoryButton = new JButton("Transaction History"); // Added button for Transaction History

        Dimension buttonSize = new Dimension(180, 50);
        printButton.setPreferredSize(buttonSize);
        backButton.setPreferredSize(buttonSize);
        transactionHistoryButton.setPreferredSize(buttonSize); // Set preferred size for Transaction History button

        productListModel = new DefaultListModel<>();
        productList = new JList<>(productListModel);
        invoiceTableModel = new DefaultTableModel();
        invoiceTableModel.addColumn("Product Name");
        invoiceTableModel.addColumn("Price");
        invoiceTableModel.addColumn("Quantity");
        invoiceTableModel.addColumn("Subtotal");
        invoiceTable = new JTable(invoiceTableModel);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/inbill", "root", "");
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to connect to the database.");
            System.exit(1);
        }

        // Adding ActionListener to transactionHistoryButton
        transactionHistoryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open Transaction History frame
                Transactionhis tf = new Transactionhis();
                tf.setLocationRelativeTo(null);
                tf.setVisible(true);
            }
        });

        searchBar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                searchProduct(searchBar.getText());
            }
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                searchProduct(searchBar.getText());
            }
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                searchProduct(searchBar.getText());
            }
        });

        productList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    String selectedProduct = productList.getSelectedValue();
                    int confirmation = JOptionPane.showConfirmDialog(null, "Enter quantity for " + selectedProduct + ":");
                    if (confirmation == JOptionPane.OK_OPTION) {
                        String quantityString = JOptionPane.showInputDialog(null, "Enter quantity:");
                        try {
                            int quantity = Integer.parseInt(quantityString);
                            if (quantity > 0) {
                                addProductToInvoice(selectedProduct, quantity);
                                updateProductQuantity(selectedProduct, quantity);
                            } else {
                                JOptionPane.showMessageDialog(null, "Quantity must be a positive integer.");
                            }
                        } catch (NumberFormatException ex) {
                            JOptionPane.showMessageDialog(null, "Invalid quantity entered. Please enter a valid number.");
                        }
                    }
                }
            }
        });

        printButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                printInvoice();
            }
        });

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                InsertMedicines mp = new InsertMedicines();
                dispose();
                 mp.setVisible(true);
            }
        });

        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel(new FlowLayout());
        topPanel.add(searchBar);
        add(topPanel, BorderLayout.NORTH);
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(new JScrollPane(productList), BorderLayout.WEST);
        centerPanel.add(new JScrollPane(invoiceTable), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomPanel.add(totalLabel);
        bottomPanel.add(printButton);
        bottomPanel.add(backButton);
        bottomPanel.add(transactionHistoryButton); // Added Transaction History button
        add(bottomPanel, BorderLayout.SOUTH);
        setTitle("Invoice Billing System");
        setSize(1200, 900);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    private void searchProduct(String query) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT product_name FROM products WHERE product_name LIKE '%" + query + "%'");
            productListModel.clear();
            while (resultSet.next()) {
                String productName = resultSet.getString("product_name");
                productListModel.addElement(productName);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to search for products.");
        }
    }

    private void addProductToInvoice(String productName, int quantity) {
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM products WHERE product_name = ? AND quantity >= ?");
            statement.setString(1, productName);
            statement.setInt(2, quantity);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                double price = resultSet.getDouble("price_per_unit");
                double subtotal = price * quantity;
                Object[] rowData = {productName, price, quantity, subtotal};
                invoiceTableModel.addRow(rowData);
                updateTotal();
            } else {
                JOptionPane.showMessageDialog(null, "Insufficient quantity available in the Stock for " + productName + ".");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred while adding product to invoice.");
        }
    }

    private void updateTotal() {
        double total = 0;
        for (int i = 0; i < invoiceTableModel.getRowCount(); i++) {
            total += (double) invoiceTableModel.getValueAt(i, 3);
        }
        totalLabel.setText("Total: ₹" + String.format("%.2f", total));
    }

    private void clearInvoiceTable() {
        invoiceTableModel.setRowCount(0);
        totalLabel.setText("Total: ₹0.00");
    }

    private void storePrintedBillInDatabase() {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO printed_bills (product_name, price, quantity, subtotal, total) VALUES (?, ?, ?, ?, ?)");
            for (int i = 0; i < invoiceTableModel.getRowCount(); i++) {
                String productName = (String) invoiceTableModel.getValueAt(i, 0);
                double price = (double) invoiceTableModel.getValueAt(i, 1);
                int quantity = (int) invoiceTableModel.getValueAt(i, 2);
                double subtotal = (double) invoiceTableModel.getValueAt(i, 3);
                double total = getTotalAmount();
                statement.setString(1, productName);
                statement.setDouble(2, price);
                statement.setInt(3, quantity);
                statement.setDouble(4, subtotal);
                statement.setDouble(5, total);
                statement.executeUpdate();
            }
            JOptionPane.showMessageDialog(null, "Printed bill stored in the database.");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to store printed bill in the database.");
        }
    }

    private void printInvoice() {
        try {
            String PDF_PATH = "Invoice.pdf";
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(PDF_PATH));
            document.open();
            com.itextpdf.text.Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            Paragraph title = new Paragraph("Invoice", titleFont);
            title.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(title);
            PdfPTable table = new PdfPTable(4);
            table.setWidthPercentage(100);
            table.addCell("Product Name");
            table.addCell("Price");
            table.addCell("Quantity");
            table.addCell("Subtotal");
            for (int i = 0; i < invoiceTableModel.getRowCount(); i++) {
                String productName = (String) invoiceTableModel.getValueAt(i, 0);
                double price = (double) invoiceTableModel.getValueAt(i, 1);
                int quantity = (int) invoiceTableModel.getValueAt(i, 2);
                double subtotal = (double) invoiceTableModel.getValueAt(i, 3);
                table.addCell(productName);
                table.addCell(String.valueOf(price));
                table.addCell(String.valueOf(quantity));
                table.addCell(String.valueOf(subtotal));
            }
            document.add(new Paragraph("Selected Items:"));
            document.add(table);
            double total = getTotalAmount();
            document.add(new Paragraph("\nTotal Amount: $" + String.format("%.2f", total)));
            document.close();
            JOptionPane.showMessageDialog(null, "Invoice saved as PDF.");
            storePrintedBillInDatabase();
            clearInvoiceTable();
        } catch (FileNotFoundException | DocumentException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error occurred while saving the invoice as PDF.");
        }
    }

    private double getTotalAmount() {
        double total = 0;
        for (int i = 0; i < invoiceTableModel.getRowCount(); i++) {
            total += (double) invoiceTableModel.getValueAt(i, 3);
        }
        return total;
    }

    private void updateProductQuantity(String productName, int quantity) {
        try {
            PreparedStatement statement = connection.prepareStatement("UPDATE products SET quantity = quantity - ? WHERE product_name = ?");
            statement.setInt(1, quantity);
            statement.setString(2, productName);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to update product quantity.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InvoiceBillingSystem frame = new InvoiceBillingSystem();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}

