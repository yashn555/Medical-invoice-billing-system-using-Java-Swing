import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SplashScreen extends JWindow {
    private int progress;
    private Timer timer;
    
    public SplashScreen() {
        progress = 0;
        setSize(500, 100);
        setLocationRelativeTo(null); 
        setLayout(new BorderLayout());
        
        // Create a panel for the splash screen content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.setBackground(Color.WHITE); 
        add(contentPanel);
        
        // Create a title label
        JLabel titleLabel = new JLabel("Medical Billing System", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 16)); // Set font to bold
        contentPanel.add(titleLabel, BorderLayout.NORTH);
        
        // Create a panel for the progress bar
        JPanel progressPanel = new JPanel();
        progressPanel.setLayout(new BorderLayout());
        progressPanel.setBackground(Color.WHITE);
        contentPanel.add(progressPanel, BorderLayout.CENTER);
        
        // Create a progress bar
        JProgressBar progressBar = new JProgressBar();
        progressBar.setStringPainted(true); 
        progressPanel.add(progressBar);
        
        // Timer to update progress
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (progress < 100) {
                    progress += 20;
                    progressBar.setValue(progress);
                } else {
                    timer.stop();
                    dispose(); 
            InvoiceBillingSystem frame = new InvoiceBillingSystem();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
                }
            }
        });
        timer.start();
    }
    
    public static void main(String[] args) {
        SplashScreen splash = new SplashScreen();
        splash.setVisible(true);
    }
}
